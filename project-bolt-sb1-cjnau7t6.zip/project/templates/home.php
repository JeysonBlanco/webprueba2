<?php
/**
 * Template Name: Home
 */

get_header();
get_template_part('template-parts/hero', 'home');
get_template_part('template-parts/services', 'preview');
get_template_part('template-parts/why-choose-us');
get_template_part('template-parts/cta');
get_footer();