<?php
/**
 * Template Name: Customs Advisory
 */

get_header();
get_template_part('template-parts/hero', 'page');
get_template_part('template-parts/customs', 'services');
get_template_part('template-parts/customs', 'benefits');
get_template_part('template-parts/cta');
get_footer();