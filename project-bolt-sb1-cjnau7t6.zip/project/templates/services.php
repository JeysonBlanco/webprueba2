<?php
/**
 * Template Name: Transport Services
 */

get_header();
get_template_part('template-parts/hero', 'page');
get_template_part('template-parts/services', 'full');
get_template_part('template-parts/cta');
get_footer();