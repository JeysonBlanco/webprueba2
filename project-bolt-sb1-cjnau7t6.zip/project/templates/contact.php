<?php
/**
 * Template Name: Contact
 */

get_header();
get_template_part('template-parts/hero', 'page');
get_template_part('template-parts/contact', 'form');
get_template_part('template-parts/contact', 'info');
get_footer();