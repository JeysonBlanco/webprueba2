<?php
if (!defined('ABSPATH')) exit;

// Define theme constants
define('FF_THEME_DIR', get_template_directory());
define('FF_THEME_URI', get_template_directory_uri());

// Load required files
require_once FF_THEME_DIR . '/inc/setup.php';
require_once FF_THEME_DIR . '/inc/enqueue.php';
require_once FF_THEME_DIR . '/inc/widgets.php';
require_once FF_THEME_DIR . '/inc/theme-setup.php';

// Theme setup
function ff_theme_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    
    // Register menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'freight-forwarder'),
        'footer' => __('Footer Menu', 'freight-forwarder'),
    ));
}
add_action('after_setup_theme', 'ff_theme_setup');

// Create default pages on theme activation
function ff_create_default_pages() {
    $default_pages = array(
        'home' => array(
            'title' => 'Home',
            'template' => 'templates/home.php',
            'content' => '<!-- Default home page content -->',
        ),
        'services' => array(
            'title' => 'Transport Services',
            'template' => 'templates/services.php',
            'content' => '<!-- Default services content -->',
        ),
        'logistics' => array(
            'title' => 'Logistics & Storage',
            'template' => 'templates/logistics.php',
            'content' => '<!-- Default logistics content -->',
        ),
        'customs' => array(
            'title' => 'Customs Advisory',
            'template' => 'templates/customs.php',
            'content' => '<!-- Default customs content -->',
        ),
        'contact' => array(
            'title' => 'Contact Us',
            'template' => 'templates/contact.php',
            'content' => '<!-- Default contact content -->',
        ),
    );

    foreach ($default_pages as $slug => $page) {
        $existing_page = get_page_by_path($slug);
        
        if (!$existing_page) {
            wp_insert_post(array(
                'post_title' => $page['title'],
                'post_name' => $slug,
                'post_status' => 'publish',
                'post_type' => 'page',
                'post_content' => $page['content'],
                'page_template' => $page['template'],
            ));
        }
    }
}
add_action('after_switch_theme', 'ff_create_default_pages');